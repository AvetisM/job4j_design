# job4j_design

[![Build Status](https://app.travis-ci.com/AvetisM/job4j_design.svg?branch=master)](https://app.travis-ci.com/AvetisM/job4j_design)

[![codecov](https://codecov.io/gh/AvetisM/job4j_design/branch/master/graph/badge.svg?token=R84IFACVPZ)](https://codecov.io/gh/AvetisM/job4j_design)