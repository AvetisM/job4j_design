package ru.job4j.io.chat;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ConsoleChat {

    private final String path;
    private final String botAnswers;
    private static final String OUT = "закончить";
    private static final String STOP = "стоп";
    private static final String CONTINUE = "продолжить";

    public ConsoleChat(String path, String botAnswers) {
        this.path = path;
        this.botAnswers = botAnswers;
    }

    public void run() {
       List<String> answers = readPhrases();
       List<String> log = new ArrayList<>();
       String inUser = "";
       Scanner scanner = new Scanner(System.in);
       while (inUser.equals(OUT)) {
           inUser = scanner.nextLine();
           log.add(inUser);
           if (!inUser.equals(STOP)) {
               int index = (int) (Math.random() * answers.size());
               String answer = answers.get(index);
               log.add(answer);
               System.out.println(answer);
           }
       }
        saveLog(log);
    }

    private List<String> readPhrases() {
        UsageEncoding encoding = new UsageEncoding();
        String strings = encoding.readFile(botAnswers);
        return List.of(strings.split(";"));
    }

    private void saveLog(List<String> log) {
        UsageEncoding encoding = new UsageEncoding();
        encoding.writeDataInFile(path, log);
    }

    public static void main(String[] args) {
        ConsoleChat cc = new ConsoleChat("./data/log.txt", "./data/botAnswers.txt");
        cc.run();
    }
}
